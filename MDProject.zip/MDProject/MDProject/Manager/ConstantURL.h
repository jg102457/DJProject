
#ifndef ConstantURL_h
#define ConstantURL_h
#endif /* ConstantURL_h*/


#define APP_BASIC_HTTPURL @"http://192.168.1.155:8080/PayWeb/mobile/mobile"
#define APP_BASIC_IMGURL @"http://192.168.1.155:8080/PayWeb/skin/appbank/"
#define GETEXPANDMODURL @"http://192.168.1.155:8080/PayWeb/mobile"



