

#ifndef MXDminxin_GlobleConfig_h
#define MXDminxin_GlobleConfig_h

#ifdef DEBUG
#define NSLog(format, ...) NSLog(format, ## __VA_ARGS__)
#define kNotePoint @"0" // debug模式下不记录友盟统计
#else
#define NSLog(format, ...)
#define kNotePoint @"1"     // release模式下记录友盟统计
#endif
// 1.颜色
#define KColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define KRGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#define BASEYELLOWCOLOR [ToolUtils colorWithHexString:@"#c8a063"]

#define BASEBLUECOLOR [ToolUtils colorWithHexString:@"#467cd4"]

#define BASEREDCOLOR [ToolUtils colorWithHexString:@"#d44656"]

#define BASEGREENCOLOR [ToolUtils colorWithHexString:@"#43b482"]

#define BASEGRAYCOLOR [ToolUtils colorWithHexString:@"#c5cddb"]

// 2.随机色
#define KRandomColor KColor(arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256))

// 4.是否为4inch
#define KfourInch ([UIScreen mainScreen].bounds.size.height == 568)
// 4.是否为320
#define IF5S ([UIScreen mainScreen].bounds.size.width == 320)
// 5.屏幕尺寸
#define KScreenW [UIScreen mainScreen].bounds.size.width
#define KScreenH [UIScreen mainScreen].bounds.size.height
//#define
#define xx_define_h
//self.frame
#define UIX [[UIScreen mainScreen] bounds].origin.x
#define UIY [[UIScreen mainScreen] bounds].origin.y
#define UIH [[UIScreen mainScreen] bounds].size.height
#define UIW [[UIScreen mainScreen] bounds].size.width
//颜色
#define COLOR(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define BGCOLOR [UIColor colorWithRed:240/255.0 green:241/255.0 blue:242/255.0 alpha:1]//背景颜色
#define YELLOWCOLOR [UIColor colorWithHue:38/360.0 saturation:0.88 brightness:0.99 alpha:1.0]//浅黄
#define DEEPYELLOWCOLOR [UIColor colorWithHue:16/360.0 saturation:0.84 brightness:0.99 alpha:1.0] //深黄
#define REDCOLOR [UIColor colorWithHue:357/360.0 saturation:0.81 brightness:0.98 alpha:1.0] //红
#define BLUECOLOR [UIColor colorWithHue:219/360.0 saturation:0.85 brightness:1 alpha:1.0]  //蓝
#define BLACKCOLOR [UIColor colorWithHue:219/360.0 saturation:0.85 brightness:1 alpha:1.0]  //黑
#define BORDERCOLOR [UIColor colorWithRed:51/255.0 green:153/255.0 blue:51/255.0 alpha:1]  //主题绿
#define SUBCOLOR [UIColor colorWithRed:102/255.0 green:204/255.0 blue:102/255.0 alpha:1] //子标题绿
#define TBLUECOLOR [UIColor colorWithRed:36/255.0 green:127/255.0 blue:230/255.0 alpha:1] //
#define ALERTCOLOR [UIColor colorWithRed:232/255.0 green:73/255.0 blue:37/255.0 alpha:1]//警告色
#define LINECOLOR [UIColor colorWithRed:233/255.0 green:233/255.0 blue:233/255.0 alpha:1]//
#define BACKCOLOR [UIColor colorWithRed:235/255.0 green:235/255.0 blue:241/255.0 alpha:0.8]//


#define TABBARHEIGHT 49
#define IOS_VERSION [[[UIDevice currentDevice]systemVersion] floatValue]
#define NAVIGATIONBAR_HEIGHT (IOS_VERSION>=7.0?64:44)

#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREEN_WIDTH  [[UIScreen mainScreen] bounds].size.width
#define VIEWWIDTH self.view.frame.size.width
#define VIEWHEIGHT self.view.frame.size.height
#define VIEWWIDTH_WITHOUTVIEW self.frame.size.width
#define VIEWHEIGHT_WITHOUTVIEW self.frame.size.height
//控件frame
#define ViewWidth(v)                 v.frame.size.width
#define ViewHeight(v)                v.frame.size.height
#define ViewX(v)                     v.frame.origin.x
#define ViewY(v)                     v.frame.origin.y
#define ImageNamed(_pointer)         [UIImage imageNamed:_pointer]


#define UserDefaults                 [NSUserDefaults standardUserDefaults]
#define SetUserDefaultsForKey(value,key)               [[NSUserDefaults standardUserDefaults] setObject:value forKey:key]
#define GetUserDefaultsForKey(key)   [[NSUserDefaults standardUserDefaults] objectForKey:key]
#define RemoveUserDefaultsForKey(key)   [[NSUserDefaults standardUserDefaults] removeObjectForKey:key]

#define Bundle                       [NSBundle mainBundle]
#define ScreenSize                   [UIScreen mainScreen].bounds.size
#define ScreenWidth                 [UIScreen mainScreen].bounds.size.width
#define ScreenHeight                [UIScreen mainScreen].bounds.size.height

#define TabBarMoveSelectAtIndex(index) [[(AppDelegate *)[UIApplication sharedApplication].delegate tabView] moveBottomLineWithIndex:index];
#define NSStringWithFormat(...) [NSString stringWithFormat:__VA_ARGS__]
#define kBannerHeight 165
#define ADAPTER SCREEN_WIDTH/375
//如果release状态下不执行NSlog
//Log打印
#ifdef DEBUG
#define DLog(...) NSLog(__VA_ARGS__)
#else
#define DLog(...) /* */
#endif
#define ALog(...) NSLog(__VA_ARGS__)
// 三种网络状态的通知事件
//#define KMXDNetworkStatusConnect @"kMXDNetworkConnect"
//#define kMXDNetworkStatusError @"kMXDNetworkError"
//#define kMXDNetworkStatusBlock @"kMXDNetworkBlock"
//
//#define kRequestKey @"CHINESE_M#!@_2342##@1%@#$@%1121^$%$"
//
//#define kMXDHandPickSwitchOFF   @"handPickSwitch"
//#define kMXDTimeLimitSwitchOFF  @"timeLimitSwitch"

/**notifacationKey**/
//#define kMXDNOTIFACATION_KEY
//判断机型
#define iPhone4 CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size)
#define iPhone5 CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size)
#define iPhone6 CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size)
#define iPhone6P CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size)
//判断系统
#define IsIOS71 ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 7.1? YES : NO)
#define IsIOS6UP ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 6.0? YES : NO)
#define IsIOS6 ([[[UIDevice currentDevice] systemVersion] doubleValue] < 7.0? YES : NO)
#define IsIOS7 ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 7.0? YES : NO)
#define IsIOS8 ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0? YES : NO)
/* 其它类型的 */

#define WeakSelf(self) __weak typeof (&*self) weakSelf = self
#define StrongSelf(strongSelf) __strong typeof (&*weakSelf) strongSelf = weakSelf

/**
 *	永久存储对象
 *
 *	@param	object    需存储的对象
 *	@param	key    对应的key
 */
#define DEF_PERSISTENT_SET_OBJECT(object, key)                                                                                                 \
({                                                                                                                                             \
NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];                                                                         \
[defaults setObject:object forKey:key];                                                                                                    \
[defaults synchronize];                                                                                                                    \
})

/**
 *	取出永久存储的对象
 *
 *	@param	key    所需对象对应的key
 *	@return	key所对应的对象
 */
#define DEF_PERSISTENT_GET_OBJECT(key) [[NSUserDefaults standardUserDefaults] objectForKey:key]

#define screenScale 2

#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )


/**
 自定义的方法
 **/
#define GetTypeJudge [_type isEqualToString:@"1"] ? @"1":@"0";
#define GetVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
#define CornerRadius ScreenWidth * 0.014
#endif
