//
//  LoginViewController.m
//  RRLProject
//
//  Created by ylq on 2017/10/10.
//  Copyright © 2017年 YLQ. All rights reserved.
//

#import "LoginViewController.h"
#import "MyTabBarViewController.h"
@interface LoginViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *HeaderIMGView;
@property (strong, nonatomic) IBOutlet UITextField *AccountTF;
@property (strong, nonatomic) IBOutlet UITextField *PassWordTF;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   // self.navigationController.navigationBarHidden = YES;
}
- (IBAction)forgetBtnClick:(UIButton *)sender {
}

- (IBAction)loginBtnClick:(UIButton *)sender {
    
    MyTabBarViewController*vc=[[MyTabBarViewController alloc]init];
    self.view.window.rootViewController=vc;
    
}

@end
