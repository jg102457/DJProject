//
//  UIAppDelegate.h
//  EasyPay
//
//  Created by ylq on 2017/9/13.
//  Copyright © 2017年 goldenseasoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MLSOAppDelegate.h"
@interface UIAppDelegate : NSObject<MLAppService>

@end
