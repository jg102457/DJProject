//
//  AppDelegate.h
//  EasyPay
//
//  Created by ylq on 2017/3/29.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLSOAppDelegate.h"
@interface AppDelegate : MLSOAppDelegate

@property (nonatomic,strong) NSURL *url;
@property (nonatomic,strong) NSString *state;
@end

