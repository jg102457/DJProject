//
//  UIAppDelegate.m
//  EasyPay
//
//  Created by ylq on 2017/9/13.
//  Copyright © 2017年 goldenseasoft. All rights reserved.
//

#import "UIAppDelegate.h"
#import "MyTabBarViewController.h"
#import "LoginViewController.h"
#import "XHLaunchAd.h"
#define imageURL1 @"http://c.hiphotos.baidu.com/image/pic/item/4d086e061d950a7b78c4e5d703d162d9f2d3c934.jpg"
#define imageURL5 @"http://c.hiphotos.baidu.com/image/pic/item/d62a6059252dd42a6a943c180b3b5bb5c8eab8e7.jpg"
@implementation UIAppDelegate
ML_EXPORT_SERVICE(@"UiAppService")
-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{

    UIWindow *Mainwindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    application.delegate.window = Mainwindow;
    Mainwindow.backgroundColor = [UIColor whiteColor];
    /*
     @开启键盘管理工具
     */
    [ToolUtils openIQkeyBoradManger];
   
    /*
     @开启第一次应用管理
     */
    [self firstOpenTheApp];
    /*
     @广告开启
     */
    //    [XHLaunchAd showWithAdFrame:[UIScreen mainScreen].bounds setAdImage:^(XHLaunchAd *launchAd) {
    //
    //        //未检测到广告数据,启动页停留时间,默认3,(设置4即表示:启动页显示了4s,还未检测到广告数据,就自动进入window根控制器)
    //        launchAd.noDataDuration = 1;
    //        //2.->设置广告数据(数据源方法)
    //        [launchAd setImageUrl:imageURL1 duration:5 skipType:SkipTypeTimeText options:0 completed:^(UIImage *image, NSURL *url) {
    //
    //        } click:^{
    //
    //
    //            //广告点击事件
    ////            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:广告点击跳转链接]];
    //            NSLog(@"点击了广告");
    //        }];
    //
    //    } showFinish:^{
    //
    NSArray *windows = [[UIApplication sharedApplication] windows];
    for(UIWindow *window in windows) {
        if(Mainwindow.window.rootViewController == nil){
            UIViewController* vc = [[UIViewController alloc]initWithNibName:nil bundle:nil];
            Mainwindow.backgroundColor =[UIColor whiteColor];
            Mainwindow.rootViewController = vc;
        }
    }
    
    if (DEF_PERSISTENT_GET_OBJECT(@"jsessionid")!=0||DEF_PERSISTENT_GET_OBJECT(@"jsessionid")!=nil ){
        
        MyTabBarViewController*vc=[[MyTabBarViewController alloc]init];
        Mainwindow.rootViewController=vc;
        
        
    }else{
        
        LoginViewController *login = [[LoginViewController alloc] init];
        UINavigationController*nc=[[UINavigationController alloc]initWithRootViewController:login];
        Mainwindow.rootViewController=nc;
        

    }

    [Mainwindow makeKeyAndVisible];
    
    return YES;

}
- (void)firstOpenTheApp{
    if (![DEF_PERSISTENT_GET_OBJECT(@"ifOpend") boolValue]) {
       
    }
    
}

@end
