//
//  MLSOAppDelegate.h
//  MLAppServiceLoader
//

#import <UIKit/UIKit.h>
#import "MLAppServiceManager.h"

@interface MLSOAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

