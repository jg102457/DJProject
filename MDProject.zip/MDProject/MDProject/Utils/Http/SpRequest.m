//
//  SpRequest.m
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import "SpRequest.h"
@implementation SpRequest

+ (void)postAFNSessionWithURL:(NSString *)url params:(NSDictionary *)params success:(SuccessBlock)success failure:(AFNErrorBlock)failure{
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    manger.responseSerializer = [AFHTTPResponseSerializer serializer];

   // [manger.requestSerializer];
    //使用默认的接受类型,如果不在默认的范围内 放开如下方法,单独设置
   // manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manger POST:url parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        if (success) {
            NSDictionary *newDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
            //解析
            success(newDic,YES);
        } else {
            success(@{@"msg":@"暂无数据"}, NO);
        }
        
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
       
        failure(error);
        
    }];
    
}
+ (void)postAFNSessionWithURL:(NSString *)url
                       params:(NSDictionary *)params
                      addToView:(UIView *)view
                      success:(SuccessBlock)success
                      failure:(AFNErrorBlock)failure{
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    manger.responseSerializer = [AFHTTPResponseSerializer serializer];
    //使用默认的接受类型,如果不在默认的范围内 放开如下方法,单独设置
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.removeFromSuperViewOnHide = YES;
    
    //manger.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manger POST:url parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        hud.hidden = YES;
        if (success) {
            NSDictionary *newDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
            //解析
            success(newDic,YES);
        } else {
            success(@{@"msg":@"暂无数据"}, NO);
        }
        
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        hud.hidden = YES;
        failure(error);
    
    }];
    
}
/*文件流上传*/
+ (void)upLoadAFHttPSessionWithURL:(NSString *)URL
                      andInputKeys:(NSDictionary *)dic
                       andFileName:(NSArray *)name
                       andImageArr:(NSArray *)imageArr
                   andAddHudToView:(UIView *)view
                   andProgressType:(ProgressTpye *)progressType
                           Success:(SuccessBlock)success
                           failure:(AFNErrorBlock)failure{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.removeFromSuperViewOnHide = YES;
    hud.mode = (MBProgressHUDMode)progressType;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //2.上传文件
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json", @"text/plain", @"text/html", nil];
    [manager POST:URL parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        /*data形式*/
        //上传文件参数
        for (int i=0; i<imageArr.count; i++) {
            UIImage *image = imageArr[i];
            NSData *data = UIImageJPEGRepresentation(image,0.5);
            //这个就是参数
            [formData appendPartWithFileData:data name:name[i] fileName:[NSString stringWithFormat:@"%@_%d.jpeg",name[i],i] mimeType:@"image/jpeg"];
        }
              /*URL形式*/
        //           [formData appendPartWithFileURL:[NSURL fileURLWithPath:@"文件地址"] name:@"file" fileName:@"1234.png" mimeType:@"application/octet-stream" error:nil];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        CGFloat prog = 1.0 * uploadProgress.completedUnitCount / uploadProgress.totalUnitCount;
        hud.progress = prog;
        
        //打印下上传进度
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        hud.hidden = YES;
       
        //请求成功
        NSDictionary *newDic = responseObject;
        //解析
        success(newDic,YES);

        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        hud.hidden = YES;
        //请求失败
        failure(error);
    }];


}
/*!
 
 * @brief 把格式化的JSON格式的字符串转换成字典
 
 * @param jsonString JSON格式的字符串
 
 * @return 返回字典
 
 */
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        
        return nil;
        
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *err;
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                         
                                                        options:NSJSONReadingMutableContainers
                         
                                                          error:&err];
    
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
        
    }
    
    return dic;
    
}

//词典转换为字符串

+ (NSString*)dictionaryToJson:(NSDictionary *)dic

{
    
    NSError *parseError = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}
- (void)AFNetworkStatus{
    
    //1.创建网络监测者
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    /*枚举里面四个状态  分别对应 未知 无网络 数据 WiFi
     typedef NS_ENUM(NSInteger, AFNetworkReachabilityStatus) {
     AFNetworkReachabilityStatusUnknown          = -1,      未知
     AFNetworkReachabilityStatusNotReachable     = 0,       无网络
     AFNetworkReachabilityStatusReachableViaWWAN = 1,       蜂窝数据网络
     AFNetworkReachabilityStatusReachableViaWiFi = 2,       WiFi
     };
     */
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        //这里是监测到网络改变的block  可以写成switch方便
        //在里面可以随便写事件
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知网络状态");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"无网络");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"蜂窝数据网");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"WiFi网络");
                
                break;
                
            default:
                break;
        }
        
    }] ;
}
@end
