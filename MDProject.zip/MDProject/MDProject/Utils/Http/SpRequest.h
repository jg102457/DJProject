//
//  SpRequest.h
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import <Foundation/Foundation.h>
#define kTimeOutInterval 30 // 请求超时的时间
typedef enum {
    
    ProgressTpyeIndeterminate,
    /** 用饼图显示进度 */
    ProgressTpyeDeterminate,
    /** 进度条 */
    ProgressTpyeDeterminateHorizontalBar,
    /** 圆环 */
    ProgressTpyeAnnularDeterminate,
    /** 自定义视图 */
    ProgressTpyeCustomView,
    /** 只显示文字 */
    ProgressTpyeText
    
}ProgressTpye;
typedef void (^SuccessBlock)(NSDictionary *dict, BOOL success);// 访问成功block
typedef void (^AFNErrorBlock)(NSError *error); // 访问失败block
@interface SpRequest : NSObject
@property (assign,nonatomic) ProgressTpye * progressType;
/**
 *  发送一个POST请求
 *
 *  @param url     请求路径
 *  @param params  请求参数
 *  @param success 请求成功后的回调
 *  @param failure 请求失败后的回调
 */
+ (void)postAFNSessionWithURL:(NSString *)url
                       params:(NSDictionary *)params
                      success:(SuccessBlock)success
                      failure:(AFNErrorBlock)failure;
/**
 *  发送一个POST请求
 *
 *  @param url     请求路径
 *  @param params  请求参数
 *  @param view 菊花
 *  @param success 请求成功后的回调
 *  @param failure 请求失败后的回调
 */
+ (void)postAFNSessionWithURL:(NSString *)url
                       params:(NSDictionary *)params
                    addToView:(UIView *)view
                      success:(SuccessBlock)success
                      failure:(AFNErrorBlock)failure;

/**
 *  (上传文件数据)
 *
 *  @param URL     请求路径
 *  @param dic  请求参数
 *  @param name 文件名字
 *  @parma imageArr 图片数组（图片名字）
 *  @parma view hud加载的视图
 *  @parma progressType 加载样式
 *  @param success 请求成功后的回调
 *  @param failure 请求失败后的回调
 */
+ (void)upLoadAFHttPSessionWithURL:(NSString *)URL
                      andInputKeys:(NSDictionary *)dic
                       andFileName:(NSArray *)name
                       andImageArr:(NSArray *)imageArr
                   andAddHudToView:(UIView *)view
                   andProgressType:(ProgressTpye *)progressType
                           Success:(SuccessBlock)success
                           failure:(AFNErrorBlock)failure;
//词典转换为字符串
+ (NSString*)dictionaryToJson:(NSDictionary *)dic;
/*
 
 * @brief 把格式化的JSON格式的字符串转换成字典
 
 * @param jsonString JSON格式的字符串
 
 * @return 返回字典
 
 */

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
@end
