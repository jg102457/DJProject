//
//  NSDictionary+Null.h
//  Project
//
//  Created by ylq on 2017/11/29.
//  Copyright © 2017年 YLQ. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface NSDictionary (Null)
- (NSDictionary *)dictionaryByReplacingNullsWithBlanks;
@end
