

#import <UIKit/UIKit.h>

// 避免冲突，加前缀
@interface UIView (Frame)

@property CGFloat width;
@property CGFloat height;
@property CGFloat x;
@property CGFloat y;
@property CGFloat centerX;
@property CGFloat centerY;
@property CGSize size;
@end
