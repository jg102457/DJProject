//
//  ToolUtils.h
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//
#import <Foundation/Foundation.h>
#import "UIImageView+WebCache.h"
@interface ToolUtils : NSObject

// 获取当前App版本
+ (NSString *)getCurrentAppVersion;

// 处理url中的特殊字符
+ (NSString *)handleChineseInUrl:(NSString *)urlString;
+ (NSString *)handleSpecialInUrl:(NSString *)string;
+ (BOOL)ifUrl:(NSString *)url;
// 判断字符是否合法
+ (BOOL)checkEmail:(NSString *)str;
+ (BOOL)checkPhone:(NSString *)str;
+ (BOOL)checkIdentityCardNo:(NSString*)cardNo;
+ (BOOL)checkCardNo:(NSString*)cardNo;
+(BOOL)judgePassWordLegal:(NSString *)pass;
// 获取当前时间戳
+ (NSString *)getCurrentTimeStamp;
//加密字符串处理
+ (NSString *)stringReplace:(NSString *)userPackStr;
//字符串转译
+ (NSString*)dictionaryToJson:(NSDictionary *)dic;
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
//截取ulr参数
+ (NSMutableDictionary *)getURLParameters:(NSString *)urlStr;
//将时间戳转化为时间 月- 日 - 年
+ (NSString *)getTimeFromTimeStamp:(NSString *)timeStamp;
//将时间戳转化为时间 月- 日 - 年 时 ：分

+ (NSString *)getTimeDateFromTimeStamp:(NSString *)timeStamp;

// 隐藏手机号中间4位数字
+ (NSString *)makeMobileNumberSecureWithNormalNumber:(NSString *)
normalNum;
// 隐藏手机号低4位开始中间4位数字
+ (NSString *)makeNumberSecureWithNormalNumber:(NSString *)normalNum;
// 隐藏身份证号码
+ (NSString *)makeIdCardNumberSecureWithNormalNumber:(NSString *)normalNum;
//解决IOS 中文unicode编码问题
+ (NSString *)replaceUnicode:(NSString *)unicodeStr;

// 生成银行卡格式   如:5932-2398-2342-2323
+ (NSString *)bankCardFormat:(NSString *)string;

// 保留银行卡卡号后四位
+ (NSString *)getShortBankCardNum:(NSString *)bankNum;
// 隐藏银行卡号

+ (NSString *)hideBankCardNum:(NSString *)bankNum;


// 电话模块调用
+ (void)callServer:(NSString *)telNum;

// 根据时间戳返回相应的日期格式   如: yyyy-MM-dd HH:mm:ss
+ (NSString*)formatTimeWithNumber:(NSNumber *)_time format:(NSString *)format;

+ (NSString *)showUserTitle;

// 转换金额格式，如：￥123,456,789.00 
+(NSString *)changeNumWithNumFormatter:(NSNumber *)normalNum;

// 隐藏名字
+ (NSString *)nameHide:(NSString *)name;

+ (NSString *)md5:(NSString *)str;

// 根据Font计算字符串所需的Size
+ (CGSize)getSizeFromString:(NSString *)string withFont:(UIFont *)font withSize:(CGSize)size;

// 根据起始和终止时间戳计算剩余时间
//+ (NSString *)getDateStringBetweenStartDate:(NSNumber*)startDate EndDate:(NSNumber *)endDate;
+ (NSString *)getStringWithBetween:(NSTimeInterval)timeInterval;

// 去掉字符串中的html标签
+ (NSString *)filterHTML:(NSString *)html;

// 获取App版本号
+ (NSString *)getSystemCurrentVersion;

// UITextFeild Delegate shouldChangeCharactersInRange 中限制用户输入的金额不超过小数点后两位
+ (BOOL)checkInputNumber:(UITextField *)textField range:(NSRange)range String:(NSString *)string;
//归档数据到 name文件下
+ (void)dataSerializationWithData:(NSArray*)datas toFileName:(NSString *)name;
//从name文件下取出归档后的数据
+ (id)dataUnserializationToFromeFileName:(NSString *)name;
//转换颜色色值
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert;
+ (BOOL)validateNumber:(NSString *) textString;
//判断是否允许消息通知
+ (BOOL)isMessageNotificationServiceOpen;
+ (void)openIQkeyBoradManger;
/*随机一个16位的字符串*/
+(NSString *)randomStringWithLength:(NSInteger)len;
/*字符串转成16进制data*/
+ (NSData *)convertHexStrToData:(NSString *)str;
/*data转成16进制字符串*/
+ (NSString *)hexStringFromData:(NSData *)myD;
+ (NSString *)stringFromData:(NSData *)data;
+(NSString *)ReplacingNewLineAndWhitespaceCharactersFromJson:(NSString *)dataStr;
//根据颜色 返回图片
+(UIImage*) imageWithColor:(UIColor*)color;
@end


@interface NSString (URI)
- (NSString *)encodeURIComponent;
- (NSString *)decodeURIWithEncoding:(NSStringEncoding)encoding;

@end
