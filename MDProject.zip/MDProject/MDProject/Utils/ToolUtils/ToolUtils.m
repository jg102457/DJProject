//
//  ToolUtils.m
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import "ToolUtils.h"
#import <CommonCrypto/CommonCrypto.h>

@implementation ToolUtils

+ (NSString *)getCurrentAppVersion{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    return [infoDic objectForKey:@"CFBundleShortVersionString"];
}
+ (NSString *)stringReplace:(NSString *)userPackStr{
    NSString* str =[userPackStr stringByReplacingOccurrencesOfString:@"\\\"" withString:@"\""];
    NSString*sting=[str stringByReplacingOccurrencesOfString:@"\"{" withString:@"{"];
    NSString*sting1=[sting stringByReplacingOccurrencesOfString:@"}\"" withString:@"}"];
    return sting1;
}
//字符串转译

+ (NSString *)getTimeFromTimeStamp:(NSString * )timeStamp{
    static NSDateFormatter *dateFormatter = nil;
    if (dateFormatter == nil) {
        dateFormatter = [NSDateFormatter new];
        [dateFormatter setDateFormat:[NSString stringWithFormat:@"yyyy-MM-dd"]];
    }
    timeStamp = [NSString stringWithFormat:@"%@",timeStamp];
    NSString* timeStr=@"";
    if (timeStamp.length >3) {
         timeStr = [timeStamp substringToIndex:timeStamp.length -3];
    }
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:[timeStr longLongValue]];
    return [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:date]];
}
+ (NSString *)getTimeDateFromTimeStamp:(NSString * )timeStamp{
    static NSDateFormatter *dateFormatter = nil;
    if (dateFormatter == nil) {
        dateFormatter = [NSDateFormatter new];
        [dateFormatter setDateFormat:[NSString stringWithFormat:@"yyyy-MM-dd H:mm"]];
    }
    timeStamp = [NSString stringWithFormat:@"%@",timeStamp];
    NSString* timeStr=@"";
    if (timeStamp.length >3) {
        timeStr = [timeStamp substringToIndex:timeStamp.length -3];
    }
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:[timeStr longLongValue]];
    return [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:date]];
}
+ (BOOL)ifUrl:(NSString *)url
{
    NSString *regex =@"[a-zA-z]+://[^\\s]*";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    return [urlTest evaluateWithObject:url];
}

+ (NSString *)handleChineseInUrl:(NSString *)urlString{
    const char *c = [urlString UTF8String];
    NSString *handleUrl = [NSString stringWithUTF8String:c];
    handleUrl = [handleUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return handleUrl;
}

+ (NSString *)handleSpecialInUrl:(NSString *)string{
    return (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes
                                         (kCFAllocatorDefault,
                                          (CFStringRef)string,
                                          NULL,
                                          CFSTR("!*'();:@&=+$,/?%#[]"),
                                          kCFStringEncodingUTF8));
}

+ (BOOL)checkEmail:(NSString *)str{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:str];
}
+ (BOOL)validateNumber:(NSString *)textString
{
    NSString* number=@".*(\\d{11}).*";
    NSPredicate *numberPre = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",number];
    return [numberPre evaluateWithObject:textString];
}
+ (BOOL)checkPhone:(NSString *)str{
//    NSString *checkNum = @"^((\\d{11})|^((\\d{7,8})|(\\d{4}|\\d{3})-(\\d{7,8})|(\\d{4}|\\d{3})-(\\d{7,8})-(\\d{4}|\\d{3}|\\d{2}|\\d{1})|(\\d{7,8})-(\\d{4}|\\d{3}|\\d{2}|\\d{1}))$)$";
    NSString *checkNum = @"^(1\\d{10})|((\\+?86)\\d{11})$";
    NSPredicate *checktest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", checkNum];
    return [checktest evaluateWithObject:str];
}

+ (BOOL)isMessageNotificationServiceOpen {
      //iOS8 check if user allow notification
      if ([self isSystemVersioniOS8]) {// system is iOS8
               UIUserNotificationSettings *setting = [[UIApplication sharedApplication] currentUserNotificationSettings];
                if (UIUserNotificationTypeNone != setting.types) {
                       return YES;
                 }
             } else {//iOS7
                    UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
                    if(UIRemoteNotificationTypeNone != type)
                           return YES;
               }
   
         return NO;
     }

+ (BOOL)isSystemVersioniOS8 {
         //check systemVerson of device
         UIDevice *device = [UIDevice currentDevice];
         float sysVersion = [device.systemVersion floatValue];
    
        if (sysVersion >= 8.0f) {
               return YES;
            }
         return NO;
     }
+ (BOOL)checkIdentityCardNo:(NSString*)cardNo
{
    if (cardNo.length != 18) {
        return  NO;
    }
    NSArray* codeArray = [NSArray arrayWithObjects:@"7",@"9",@"10",@"5",@"8",@"4",@"2",@"1",@"6",@"3",@"7",@"9",@"10",@"5",@"8",@"4",@"2", nil];
    NSDictionary* checkCodeDic = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"1",@"0",@"X",@"9",@"8",@"7",@"6",@"5",@"4",@"3",@"2", nil]  forKeys:[NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10", nil]];
    
    NSScanner* scan = [NSScanner scannerWithString:[cardNo substringToIndex:17]];
    
    int val;
    BOOL isNum = [scan scanInt:&val] && [scan isAtEnd];
    if (!isNum) {
        return NO;
    }
    int sumValue = 0;
    
    for (int i =0; i<17; i++) {
        sumValue+=[[cardNo substringWithRange:NSMakeRange(i , 1) ] intValue]* [[codeArray objectAtIndex:i] intValue];
    }
    NSString* strlast = [checkCodeDic objectForKey:[NSString stringWithFormat:@"%d",sumValue%11]];
    
    if ([strlast isEqualToString: [[cardNo substringWithRange:NSMakeRange(17, 1)]uppercaseString]]) {
        return YES;
    }
    return  NO;
}
+ (BOOL)checkCardNo:(NSString*)cardNo{
    int oddsum = 0;     //奇数求和
    int evensum = 0;    //偶数求和
    int allsum = 0;
    int cardNoLength = (int)[cardNo length];
    int lastNum = [[cardNo substringFromIndex:cardNoLength-1] intValue];
    
    cardNo = [cardNo substringToIndex:cardNoLength - 1];
    for (int i = cardNoLength -1 ; i>=1;i--) {
        NSString *tmpString = [cardNo substringWithRange:NSMakeRange(i-1, 1)];
        int tmpVal = [tmpString intValue];
        if (cardNoLength % 2 ==1 ) {
            if((i % 2) == 0){
                tmpVal *= 2;
                if(tmpVal>=10)
                    tmpVal -= 9;
                evensum += tmpVal;
            }else{
                oddsum += tmpVal;
            }
        }else{
            if((i % 2) == 1){
                tmpVal *= 2;
                if(tmpVal>=10)
                    tmpVal -= 9;
                evensum += tmpVal;
            }else{
                oddsum += tmpVal;
            }
        }
    }
    
    allsum = oddsum + evensum;
    allsum += lastNum;
    if((allsum % 10) == 0)
        return YES;
    else
        return NO;
}
+(BOOL)judgePassWordLegal:(NSString *)pass{
    BOOL result = false;
    if ([pass length] >= 6){
        // 判断长度大于6位后再接着判断是否同时包含数字和字符
        NSString * regex = @"^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$";
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
        result = [pred evaluateWithObject:pass];
    }
    return result;
}

+ (NSString *)getSystemCurrentVersion{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDic objectForKey:@"CFBundleShortVersionString"];
    return app_Version;
}

+ (NSString *)makeMobileNumberSecureWithNormalNumber:(NSString *)normalNum{
    if (!normalNum || [normalNum isEqualToString:@"<null>"] || normalNum.length !=11){
        return @"";
    }
    NSMutableString *newNumber = [NSMutableString stringWithString:normalNum];
    [newNumber replaceCharactersInRange:NSMakeRange(3, 5) withString:@"****"];
    return newNumber;
}
+ (NSString *)makeNumberSecureWithNormalNumber:(NSString *)normalNum{
    if (normalNum.length<=7) {
        NSMutableString *newNumber = [NSMutableString stringWithString:normalNum];
        [newNumber replaceCharactersInRange:NSMakeRange(3,normalNum.length-4 ) withString:@"****"];
        return newNumber;
    }
    NSMutableString *newNumber = [NSMutableString stringWithString:normalNum];
    [newNumber replaceCharactersInRange:NSMakeRange(4, 4) withString:@"****"];
    return newNumber;
}
+ (NSString *)makeIdCardNumberSecureWithNormalNumber:(NSString *)normalNum{
    if (!normalNum || [normalNum isEqualToString:@"<null>"] || normalNum.length<=12){
        return @"";
    }
    NSMutableString *newNumber = [NSMutableString stringWithString:normalNum];
    [newNumber replaceCharactersInRange:NSMakeRange(3, normalNum.length-7) withString:@"**********"];
    return newNumber;

}
+ (NSString *)getShortBankCardNum:(NSString *)bankNum{
    if (!bankNum || [bankNum isKindOfClass:[NSNull class]] || bankNum.length <= 10){
        return @"";
    }
    NSMutableString *newNumber = [NSMutableString stringWithString:bankNum];
    [newNumber replaceCharactersInRange:NSMakeRange(0,[bankNum length]-4) withString:@""];
    return newNumber;
}
+ (NSString *)hideBankCardNum:(NSString *)bankNum{
    if (!bankNum || [bankNum isKindOfClass:[NSNull class]] || bankNum.length <= 10){
        return @"";
    }
    NSMutableString *newNumber = [NSMutableString stringWithString:bankNum];
    [newNumber replaceCharactersInRange:NSMakeRange(4,[bankNum length]-7) withString:@" **** **** **** "];
    return newNumber;

}
+ (NSString *)bankCardFormat:(NSString *)string{
    if (!string){
        return @"";
    }
    NSString *result = nil;
    NSString *space = @"-";
    NSMutableString *mutableString = [[NSMutableString alloc] init];
    [mutableString appendString:string];
    NSInteger stringLength = [mutableString length];
    if (stringLength >= 4) {
        if (stringLength%5 == 0) {
            [mutableString insertString:space atIndex:stringLength-1];
        }
        result = mutableString;
    }else{
        result = mutableString;
    }
    return result;
}

+ (void)callServer:(NSString *)telNum{
    NSString *deviceType = [UIDevice currentDevice].model;
    if([deviceType  isEqualToString:@"iPod touch"]||
       [deviceType  isEqualToString:@"iPad"]||
       [deviceType  isEqualToString:@"iPhone Simulator"]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"message:@"您的设备不能打电话" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil,nil];
        [alert show];
        return;
    }
    NSMutableString * str = [[NSMutableString alloc] initWithFormat:@"tel:%@",telNum];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}

+ (NSString*)formatTimeWithNumber:(NSNumber *)_time format:(NSString *)format{
    if (!_time || [_time isEqual:[NSNull null]]){
        return @"";
    }
    NSTimeInterval time = [_time doubleValue]/1000;
    NSDate *detaildate = [NSDate dateWithTimeIntervalSince1970:time];
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
//    [formatter setDateStyle:NSDateFormatterMediumStyle];
//    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:format];
    NSString *returnTime = [formatter stringFromDate:detaildate];
    return returnTime;
}



+(NSString *)changeNumWithNumFormatter:(NSNumber *)normalNum{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = kCFNumberFormatterCurrencyStyle;
    NSString *string = [formatter stringFromNumber:normalNum];
    string = [string stringByReplacingOccurrencesOfString:@"$" withString:@""];
    string = [string stringByReplacingOccurrencesOfString:@"￥" withString:@""];
    NSLog(@"Formatted number string:%@",string);
    return string;
}

//+ (NSString *)getDateStringBetweenStartDate:(NSNumber*)startDate EndDate:(NSNumber *)endDate{
//    NSTimeInterval start = [startDate doubleValue]/1000;
//    NSTimeInterval end = [endDate doubleValue]/1000;
//    NSTimeInterval between = end - start;
//    NSInteger seconds		= (int) between;
//    NSInteger days			= seconds / 86400;
//    NSInteger hours			= seconds % 86400;
//    NSInteger minutes		= hours % 3600;
//    seconds					= minutes % 60;
//    hours					= hours / 3600;
//    minutes					= minutes / 60;
//    NSString *resultStr = [NSString stringWithFormat:@"%02d天%02d小时%02d分%02d秒",days,hours,minutes,seconds];
//    return resultStr;
//}

+ (NSString *)filterHTML:(NSString *)html{
    if (!html || [html isEqual:[NSNull null]] || html.length <=0){
        return @"";
    }
    NSScanner * scanner = [NSScanner scannerWithString:html];
    NSString * text = nil;
    while([scanner isAtEnd]==NO){
        [scanner scanUpToString:@"<" intoString:nil];
        [scanner scanUpToString:@">" intoString:&text];
        html = [html stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@>",text] withString:@""];
    }
    html = [html stringByReplacingOccurrencesOfString:@" " withString:@""];
    return html;
}


#pragma mark - MD5
+ (NSString *)md5:(NSString *)str {
    const char *cStr = [str UTF8String];//转换成utf-8
    unsigned char result[16];//开辟一个16字节（128位：md5加密出来就是128位/bit）的空间（一个字节=8字位=8个二进制数）
    CC_MD5( cStr, strlen(cStr), result);
    /*
     extern unsigned char *CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把cStr字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了result这个空间中
     */
    return [[NSString stringWithFormat:
             @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
             result[0], result[1], result[2], result[3],
             result[4], result[5], result[6], result[7],
             result[8], result[9], result[10], result[11],
             result[12], result[13], result[14], result[15]
             ] lowercaseString];
    /*
     x表示十六进制，%02X  意思是不足两位将用0补齐，如果多余两位则不影响
     NSLog("%02X", 0x888);  //8885
     NSLog("%02X", 0x4); //04
     */
}
+ (NSString *)replaceUnicode:(NSString *)unicodeStr
{
    
    NSString *tempStr1 = [unicodeStr stringByReplacingOccurrencesOfString:@"\\u"withString:@"\\U0001"];
    NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\""withString:@"\\\""];
    NSString *tempStr3 = [[@"\""stringByAppendingString:tempStr2] stringByAppendingString:@"\""];
    NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
    NSString* returnStr = [NSPropertyListSerialization propertyListFromData:tempData
                                                           mutabilityOption:NSPropertyListImmutable
                                                                     format:NULL
                                                           errorDescription:NULL];
    return [returnStr stringByReplacingOccurrencesOfString:@"\\r\\n"withString:@"\n"];
}
+ (NSString *)getCurrentTimeStamp{
    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[dat timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%.f", a];
    NSLog(@"getCurrentTimeStamp ==== %@",timeString);
    return timeString;
}

+ (NSString *)nameHide:(NSString *)name{
    if (!name || name.length<=0){
        return @"";
    }
    NSMutableString *result = nil;
    for (int length = 0; length<name.length; length++){
        if (length == 0){
            result = [NSMutableString stringWithFormat:@"%@",[name substringWithRange:NSMakeRange(0, 1)]];
        }else{
            if (length>=3){
                // 如果名字过长只显示2个*
                break;
            }
            [result appendFormat:@"*"];
        }
    }
    return result;
}

+ (CGSize)getSizeFromString:(NSString *)string withFont:(UIFont *)font withSize:(CGSize)size{
    CGRect rect = [string boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil];
    NSLog(@"return height === %f  width === %f \n content == %@",rect.size.height,rect.size.width,string);
    return rect.size;
}

+ (BOOL)checkInputNumber:(UITextField *)textField range:(NSRange)range String:(NSString *)string{
    //输入字符限制
    NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789.\n"] invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
    if (filtered.length == 0) {
        //支持删除键
        return [string isEqualToString:@""];
    }
    if (textField.text.length == 0) {
        return ![string isEqualToString:@"."];
    }
    //第一位为0，只能输入.
    else if (textField.text.length == 1){
        if ([textField.text isEqualToString:@"0"]) {
            return [string isEqualToString:@"."];
        }
    }
    else{//只能输入一个.
        if ([textField.text rangeOfString:@"."].length) {
            if ([string isEqualToString:@"."]) {
                return NO;
            }
            //两位小数
            NSArray *ary =  [textField.text componentsSeparatedByString:@"."];
            if (ary.count == 2) {
                if ([ary[1] length] == 2) {
                    return NO;
                }
            }
        }
    }
    return YES;
}
#pragma mark - 归档数据 和 反归档数据
+ (void)dataSerializationWithData:(NSArray*)datas toFileName:(NSString *)name{
    NSString *paths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *path = [paths stringByAppendingPathComponent:name];
    [NSKeyedArchiver archiveRootObject:datas toFile:path];
}
+ (id)dataUnserializationToFromeFileName:(NSString *)name{
    NSString *paths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *path = [paths stringByAppendingPathComponent:name];
    id data = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    return data;
}
+ (NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        
        return nil;

    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *err;
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                         
                                                        options:NSJSONReadingMutableContainers
                         
                                                          error:&err];
    
    if(err) {
        
        NSLog(@"json解析失败：%@",err);
        
        return nil;
        
    }
    
    return dic;
    
}
+ (NSMutableDictionary *)getURLParameters:(NSString *)urlStr {
    
    // 查找参数
    NSRange range = [urlStr rangeOfString:@"?"];
    if (range.location == NSNotFound) {
        return nil;
    }
    
    // 以字典形式将参数返回
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    // 截取参数
    NSString *parametersString = [urlStr substringFromIndex:range.location + 1];
    
    // 判断参数是单个参数还是多个参数
    if ([parametersString containsString:@"&"]) {
        
        // 多个参数，分割参数
        NSArray *urlComponents = [parametersString componentsSeparatedByString:@"&"];
        
        for (NSString *keyValuePair in urlComponents) {
            // 生成Key/Value
            NSArray *pairComponents = [keyValuePair componentsSeparatedByString:@"="];
            NSString *key = [pairComponents.firstObject stringByRemovingPercentEncoding];
            NSString *value = [pairComponents.lastObject stringByRemovingPercentEncoding];
            
            // Key不能为nil
            if (key == nil || value == nil) {
                continue;
            }
            
            id existValue = [params valueForKey:key];
            
            if (existValue != nil) {
                
                // 已存在的值，生成数组
                if ([existValue isKindOfClass:[NSArray class]]) {
                    // 已存在的值生成数组
                    NSMutableArray *items = [NSMutableArray arrayWithArray:existValue];
                    [items addObject:value];
                    
                    [params setValue:items forKey:key];
                } else {
                    
                    // 非数组
                    [params setValue:@[existValue, value] forKey:key];
                }
                
            } else {
                
                // 设置值
                [params setValue:value forKey:key];
            }
        }
    } else {
        // 单个参数
        
        // 生成Key/Value
        NSArray *pairComponents = [parametersString componentsSeparatedByString:@"="];
        
        // 只有一个参数，没有值
        if (pairComponents.count == 1) {
            return nil;
        }
        
        // 分隔值
        NSString *key = [pairComponents.firstObject stringByRemovingPercentEncoding];
        NSString *value = [pairComponents.lastObject stringByRemovingPercentEncoding];
        
        // Key不能为nil
        if (key == nil || value == nil) {
            return nil;
        }
        
        // 设置值
        [params setValue:value forKey:key];
    }
    
    return params;
}
//字符串转译
//+ (NSString *)SBJsonWriterDict:(NSDictionary*)dataDict
//{
//    SBJsonWriter *writer = [[SBJsonWriter alloc]init];
//    NSString *sbjsonStr = [writer stringWithObject:dataDict];
//    return sbjsonStr;
//}

+ (UIColor *)colorWithHexString:(NSString *)stringToConvert
{
    NSString *cString = [[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor whiteColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    else if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];
    if ([cString length] != 6) return [UIColor whiteColor];
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

/*开启键盘管理工具*/
+ (void)openIQkeyBoradManger{
    
    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = YES;
    manager.shouldResignOnTouchOutside = YES;
    manager.shouldToolbarUsesTextFieldTintColor = YES;
    manager.enableAutoToolbar = NO;
    
    
}
+(NSString *)ReplacingNewLineAndWhitespaceCharactersFromJson:(NSString *)dataStr{
    NSScanner *scanner = [[NSScanner alloc] initWithString:dataStr];
    [scanner setCharactersToBeSkipped:nil];
    NSMutableString *result = [[NSMutableString alloc] init];
    
    NSString *temp;
    NSCharacterSet*newLineAndWhitespaceCharacters = [ NSCharacterSet newlineCharacterSet];
    // 扫描
    while (![scanner isAtEnd])
    {
        temp = nil;
        [scanner scanUpToCharactersFromSet:newLineAndWhitespaceCharacters intoString:&temp];
        if (temp) [result appendString:temp];
        
        // 替换换行符
        if ([scanner scanCharactersFromSet:newLineAndWhitespaceCharacters intoString:NULL]) {
            if (result.length > 0 && ![scanner isAtEnd]) // Dont append space to beginning or end of result
                [result appendString:@"|"];
        }
    }
    return result;
}

/*随机一个16位字符串*/
+(NSString *)randomStringWithLength:(NSInteger)len{
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    
    for (NSInteger i = 0; i < len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform([letters length])]];
    }
    return randomString;
}

+ (NSData *)convertHexStrToData:(NSString *)str {
    if (!str || [str length] == 0) {
        return nil;
    }
    
    NSMutableData *hexData = [[NSMutableData alloc] initWithCapacity:8];
    NSRange range;
    if ([str length] % 2 == 0) {
        range = NSMakeRange(0, 2);
    } else {
        range = NSMakeRange(0, 1);
    }
    for (NSInteger i = range.location; i < [str length]; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [str substringWithRange:range];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        
        [scanner scanHexInt:&anInt];
        NSData *entity = [[NSData alloc] initWithBytes:&anInt length:1];
        [hexData appendData:entity];
        
        range.location += range.length;
        range.length = 2;
    }
    return hexData;
}
+ (NSString *)hexStringFromData:(NSData *)myD{
    
    Byte *bytes = (Byte *)[myD bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[myD length];i++)
        
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        
        if([newHexStr length]==1)
            
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        
        else
            
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    NSLog(@"hex = %@",hexStr);
    
    return hexStr;
}
+ (NSString *)stringFromData:(NSData *)data {
    return  [[[[data description] stringByReplacingOccurrencesOfString: @"<" withString: @""]
              stringByReplacingOccurrencesOfString: @">" withString: @""]
             stringByReplacingOccurrencesOfString: @" " withString: @""];
}

+(UIImage*) imageWithColor:(UIColor*)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}
@end

@implementation NSString (URI)
- (NSString *)encodeURIComponent {
    NSString *encodedString = (NSString *)
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,(CFStringRef)self,nil,(CFStringRef)@";/?:@&=+$,#", kCFStringEncodingUTF8));
    return encodedString;
}


- (NSString *)decodeURIWithEncoding:(NSStringEncoding)encoding {
    if (!self.length) {
        return self;
    }
    return [[self stringByReplacingOccurrencesOfString:@"+" withString:@" "] stringByReplacingPercentEscapesUsingEncoding:encoding];
}
@end
