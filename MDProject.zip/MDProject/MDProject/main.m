//
//  main.m
//  MDProject
//
//  Created by ylq on 2017/12/4.
//  Copyright © 2017年 YLQ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
