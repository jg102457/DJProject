//
//  RootTableView.h
//  Project
//
//  Created by ylq on 2017/11/28.
//  Copyright © 2017年 YLQ. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol  RootTableViewDelegae<NSObject>
@optional
-(void)tableViewHeaderWithRefreshing;
-(void)tableViewFooterWithRefreshing;
@end

@interface RootTableView : UITableView
/*
 背景图
 */
@property (nonatomic,strong) UIView *backView;

/*
 背景图片
 */
@property (nonatomic,strong) UIImage *backIMG;

/*
 背景是否隐藏背景图
 */
@property (nonatomic,assign) BOOL isHiden;

/*
 刷新
 */
@property (nonatomic,assign) id<RootTableViewDelegae>refreshDelegate;


@end
