//
//  RootViewController.m
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import "RootViewController.h"
@interface RootViewController ()

@end

@implementation RootViewController{
  
}

- (UIImage *) imageWithFrame:(CGRect)frame alphe:(CGFloat)alphe {
    frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    UIColor *redColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:alphe];
    UIGraphicsBeginImageContext(frame.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [redColor CGColor]);
    CGContextFillRect(context, frame);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}


-  (void)viewWillAppear:(BOOL)animated{


}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
   // [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    //设置导航条和字体的颜色
    self.navigationController.navigationBar.barTintColor=[UIColor whiteColor];
     [self.navigationController.navigationBar setTranslucent:NO];
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:17],
       NSForegroundColorAttributeName:[UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1]}];
    //去除返回按钮的文字
    UIBarButtonItem *temporaryBarButtonItem = [[UIBarButtonItem alloc] init];
    temporaryBarButtonItem.title = @"";
    self.navigationItem.backBarButtonItem = temporaryBarButtonItem;
    
    self.navigationController.navigationBar.tintColor = [UIColor grayColor];
    [self openAFObserver];
   
}
-(void)openAFObserver{
    AFNetworkReachabilityManager *mang = [AFNetworkReachabilityManager  sharedManager];
    [mang setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"WIFI");
            {  
            }
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"自带网络");
            {
            }
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
            {  
                
                [MBProgressHUD showText:@"网络断开连接"];
            }
            
                break;
                
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知网络");
            {
            }
                break;
            default:
                break;
        }
    }];
    [mang startMonitoring];

}

@end
