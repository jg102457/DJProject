//
//  WebRootViewController.h
//  EasyPay
//
//  Created by ylq on 2017/7/24.
//  Copyright © 2017年 goldenseasoft. All rights reserved.
//

#import "RootViewController.h"

@interface WebRootViewController : RootViewController

@end
