//
//  WebRootViewController.m
//  EasyPay
//
//  Created by ylq on 2017/7/24.
//  Copyright © 2017年 goldenseasoft. All rights reserved.
//

#import "WebRootViewController.h"

@interface WebRootViewController ()<UIWebViewDelegate>
@property (nonatomic,copy) UIWebView *webView;
@end

@implementation WebRootViewController{
    MBProgressHUD *hud;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self creatUI];
}
- (void)creatUI{
    
    NSString * htmlPath ;
    if ([self.title isEqualToString:@"限额说明"]) {
       htmlPath = [[NSBundle mainBundle] pathForResource:@"index2" ofType:@"html"];
    }else{
    htmlPath = [[NSBundle mainBundle] pathForResource:@"index1" ofType:@"html"];
    }
    NSURL *baseURL = [NSURL fileURLWithPath:htmlPath];
    NSString * htmlCont = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    
    [self.webView loadHTMLString:htmlCont baseURL:baseURL];
    hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}
- (UIWebView *)webView{
    if (!_webView) {
        _webView = [[UIWebView alloc]initWithFrame:self.view.frame];
        _webView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        _webView.scrollView.bounces = NO;
        _webView.delegate = self;
        [self.view addSubview:_webView];
   
    }
    return _webView;
}
-(void)webViewDidStartLoad:(UIWebView *)webView{
  //菊花转圈
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    hud.hidden= YES;
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    hud.hidden= YES;
}
@end
