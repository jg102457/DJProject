//
//  RootViewController.h
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//

#import <UIKit/UIKit.h>
@interface RootViewController : UIViewController
@property(nonatomic,copy)NSString*navTitle;
@property (nonatomic, strong) NSString *kYPHDataJSONKey_Msg;
@property (nonatomic, assign) NSInteger kYPHDataJSONKey_Code;
@property (nonatomic, strong) NSString *kYPHDataJSONKey_Data;

@end
