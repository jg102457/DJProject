//
//  RootTableView.m
//  Project
//
//  Created by ylq on 2017/11/28.
//  Copyright © 2017年 YLQ. All rights reserved.
//

#import "RootTableView.h"

@implementation RootTableView
{
    UIImageView *placeIMG;
}
-(id)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        [self rootUI];
    }
    return self;
}
-(id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    if (self=[super initWithFrame:frame style:style]) {
       [self rootUI];
    }
    return self;
}
-(void)rootUI{
    self.tableFooterView = [UIView new];//没有footer
    self.backgroundView =self.backView;//默认背景图
    
    WeakSelf(self);
    self.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf self_headerRefresh];
        [weakSelf.mj_header endRefreshing];
    }];
    self.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [weakSelf self_footerRefresh];
        [weakSelf.mj_footer endRefreshing];
    }];

}
-(UIView *)backView{
    if (!_backView) {
        
        _backView = [[UIView alloc]initWithFrame:self.bounds];
        _backView.hidden = YES;
        _backView.backgroundColor = [UIColor whiteColor];
        placeIMG = [[UIImageView alloc]initWithFrame:CGRectMake( self.frame.size.width/4,(self.frame.size.height-64-49-(self.frame.size.width/2 * 9/8))/2-25, self.frame.size.width/2, self.frame.size.width/2 * 9/8)];
        placeIMG.userInteractionEnabled = YES;
        placeIMG.image = [UIImage imageNamed:@"arrow_right"];//默认图
        UILabel *lb =[[UILabel alloc]initWithFrame:CGRectMake(10,placeIMG.frame.size.height+placeIMG.frame.origin.y +3 , ScreenWidth-20, 22)];
        lb.text = @"暂无内容";
        lb.textAlignment =1;
        lb.textColor = [UIColor lightGrayColor];
        lb.font = [UIFont systemFontOfSize:16];
        [_backView addSubview:lb];
        [_backView addSubview:placeIMG];
        
    }
    return _backView;
}
-(void)setBackIMG:(UIImage *)backIMG{
    placeIMG.image = backIMG;
}
-(void)setIsHiden:(BOOL)isHiden{
    _backView.hidden = isHiden;
}
-(void)self_headerRefresh{
    if ([self.refreshDelegate respondsToSelector:@selector(tableViewHeaderWithRefreshing)]) {
        [self.refreshDelegate tableViewHeaderWithRefreshing];
    }
}
-(void)self_footerRefresh{
    if ([self.refreshDelegate respondsToSelector:@selector(tableViewFooterWithRefreshing)]) {
        [self.refreshDelegate tableViewFooterWithRefreshing];
    }
}
@end
