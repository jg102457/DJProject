//
//  MyTabBarViewController.m
//  //
//
//  Created by ylq on 2017/3/27.
//  Copyright © 2017年 goldenseasoft All rights reserved.
//
#import "MyTabBarViewController.h"
#import "MainViewController.h"
#import "LoanViewController.h"
#import "InvestViewController.h"
#import "MessageViewController.h"
#import "AccountViewController.h"
@interface MyTabBarViewController ()

@end

@implementation MyTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createViewControlls];
    
    [self createItem];
    
}
-(void)createItem{
    NSArray*titleArray=@[@"首页",@"贷款",@"消息",@"投资",@"账户"];
    NSArray*selectArray=@[@"nav_shouye_hover",@"nav_yinhangka_hover",@"nav_wode_hover",@"nav_wode_hover",@"nav_wode_hover"];
    NSArray*unSelectArray=@[@"nav_shouye",@"nav_yinhangka",@"nav_wode",@"nav_wode",@"nav_wode"];
    
    for (int i=0; i<self.tabBar.items.count; i++) {
        UITabBarItem*item1=self.tabBar.items[i];
        item1.title=titleArray[i];
        
        [item1 setFinishedSelectedImage:[[UIImage imageNamed:selectArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] withFinishedUnselectedImage:[[UIImage imageNamed:unSelectArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    
    //设置背景图
    [[UITabBar appearance]setBackgroundColor:[UIColor whiteColor]];
    //设置文字的颜色
    
    [[UITabBarItem appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:BLUECOLOR} forState:UIControlStateSelected];
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[ToolUtils colorWithHexString:@"#333333"], NSForegroundColorAttributeName,[UIFont systemFontOfSize:12], NSFontAttributeName, nil]
                                             forState:UIControlStateNormal];
    
}
-(void)createViewControlls{
    //
    MainViewController *vc=[[MainViewController alloc]init];
    vc.title=@"首页";
    UINavigationController*nc=[[UINavigationController alloc]initWithRootViewController:vc];
   //
    LoanViewController *vc2=[[LoanViewController alloc  ]init];
    vc2.title=@"贷款";
    UINavigationController *nc2=[[UINavigationController alloc]initWithRootViewController:vc2];
    //
    MessageViewController *vc3=[[MessageViewController alloc  ]init];
    vc3.title=@"消息";
    UINavigationController*nc3=[[UINavigationController alloc]initWithRootViewController:vc3];
    //
    InvestViewController *vc4=[[InvestViewController alloc  ]init];
    vc4.title=@"投资";
    UINavigationController*nc4=[[UINavigationController alloc]initWithRootViewController:vc4];
    //
    AccountViewController *vc5=[[AccountViewController alloc  ]init];
    vc5.title=@"账户";
    UINavigationController*nc5=[[UINavigationController alloc]initWithRootViewController:vc5];
    
    NSArray*ncArray=@[nc,nc2,nc3,nc4,nc5];
    self.viewControllers=ncArray;
    
}


- (void)dealloc{
    NSLog(@"%s", __func__);
}
@end
